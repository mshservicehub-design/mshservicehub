import React, { useState } from 'react';
import { 
  Phone, MapPin, Clock, Award, Users, Shield, CheckCircle, ArrowRight, 
  Wrench, Droplet, Paintbrush, Zap, Sun, Home 
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Types
interface Service {
  id: number;
  title: string;
  icon: React.ReactNode;
  image: string;
  description: string;
}

interface Booking {
  id: number;
  service: string;
  mobile: string;
  date: string;
  status: string;
}

const services: Service[] = [
  {
    id: 1,
    title: "AC Repair & Maintenance",
    icon: <Wrench className="w-6 h-6" />,
    image: "/images/ac-repair.jpg",
    description: "Expert AC servicing, gas refilling, and repairs"
  },
  {
    id: 2,
    title: "Plumbing Services",
    icon: <Droplet className="w-6 h-6" />,
    image: "/images/plumbing.jpg",
    description: "Pipe repairs, installations, leak fixes & more"
  },
  {
    id: 3,
    title: "Interior & Exterior Painting",
    icon: <Paintbrush className="w-6 h-6" />,
    image: "/images/painting.jpg",
    description: "Professional painting for homes and offices"
  },
  {
    id: 4,
    title: "Electrical Services",
    icon: <Zap className="w-6 h-6" />,
    image: "/images/electrical.jpg",
    description: "Wiring, switches, fans, and electrical repairs"
  },
  {
    id: 5,
    title: "Solar System Installation",
    icon: <Sun className="w-6 h-6" />,
    image: "/images/solar.jpg",
    description: "Solar panel setup and maintenance services"
  },
  {
    id: 6,
    title: "General Home Maintenance",
    icon: <Home className="w-6 h-6" />,
    image: "/images/maintenance.jpg",
    description: "Comprehensive home repairs and upkeep"
  }
];

const whyChooseUs = [
  { icon: <CheckCircle className="w-5 h-5" />, text: "₹0 Visit Charges" },
  { icon: <Shield className="w-5 h-5" />, text: "Skilled & Verified Technicians" },
  { icon: <Clock className="w-5 h-5" />, text: "Fast Response & On-Time Service" },
  { icon: <Award className="w-5 h-5" />, text: "Transparent Pricing" },
  { icon: <Phone className="w-5 h-5" />, text: "Online Booking & WhatsApp Support" },
  { icon: <Users className="w-5 h-5" />, text: "OTP Verified Service Requests" },
];

const bookingSteps = [
  "Select Your Required Service",
  "Enter Your Mobile Number",
  "Verify with OTP",
  "Confirm Your Booking",
  "Receive Instant Confirmation"
];

function App() {
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [mobile, setMobile] = useState('');
  const [otp, setOtp] = useState('');
  const [generatedOtp, setGeneratedOtp] = useState('');
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [showSuccess, setShowSuccess] = useState(false);
  const [bookingDetails, setBookingDetails] = useState<any>(null);

  // Open booking modal
  const openBooking = (service?: Service) => {
    if (service) setSelectedService(service);
    setIsBookingOpen(true);
    setCurrentStep(1);
    setMobile('');
    setOtp('');
    setGeneratedOtp('');
  };

  const closeBooking = () => {
    setIsBookingOpen(false);
    setCurrentStep(1);
    setSelectedService(null);
    setMobile('');
    setOtp('');
    setGeneratedOtp('');
    setShowSuccess(false);
  };

  // Handle service selection in booking
  const selectServiceInModal = (service: Service) => {
    setSelectedService(service);
    setCurrentStep(2);
  };

  // Send OTP (simulated)
  const sendOtp = () => {
    if (mobile.length !== 10) {
      alert("Please enter a valid 10-digit mobile number");
      return;
    }
    const newOtp = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(newOtp);
    setCurrentStep(3);
    // In real app this would be sent via SMS
    alert(`OTP sent to ${mobile}. For demo, your OTP is: ${newOtp}`);
  };

  // Verify OTP
  const verifyOtp = () => {
    if (otp === generatedOtp) {
      setCurrentStep(4);
    } else {
      alert("Invalid OTP. Please try again.");
    }
  };

  // Confirm Booking - Fully Functioning
  const confirmBooking = () => {
    if (!selectedService || !mobile) return;

    const newBooking: Booking = {
      id: Date.now(),
      service: selectedService.title,
      mobile: mobile,
      date: new Date().toLocaleDateString('en-IN', { 
        weekday: 'long', 
        month: 'long', 
        day: 'numeric' 
      }),
      status: "Confirmed"
    };

    const newBookings = [newBooking, ...bookings];
    setBookings(newBookings);

    const details = {
      service: selectedService.title,
      mobile: mobile,
      bookingId: newBooking.id,
      date: newBooking.date
    };
    setBookingDetails(details);
    
    setShowSuccess(true);
    setCurrentStep(5);
  };

  // WhatsApp Integration - Fully Working
  const contactWhatsApp = (service?: string) => {
    const message = service 
      ? `Hi MSH Service Hub, I would like to book ${service}. Please contact me.`
      : `Hi MSH Service Hub, I need home service assistance.`;
    
    const whatsappUrl = `https://wa.me/918855868697?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  // Call Phone
  const callPhone = () => {
    window.location.href = "tel:8855868697";
  };

  // Reset booking modal
  const resetAndClose = () => {
    closeBooking();
    setTimeout(() => {
      setShowSuccess(false);
      setBookingDetails(null);
    }, 300);
  };

  return (
    <div className="min-h-screen bg-white font-sans">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-md z-50 border-b">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center">
              <Home className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="font-bold text-2xl tracking-tight">MSH Service Hub</div>
              <div className="text-[10px] text-gray-500 -mt-1">PROFESSIONAL HOME SERVICES</div>
            </div>
          </div>
          
          <div className="flex items-center gap-8 text-sm font-medium">
            <a href="#services" className="hover:text-emerald-600 transition-colors">Services</a>
            <a href="#why-us" className="hover:text-emerald-600 transition-colors">Why Us</a>
            <a href="#how-it-works" className="hover:text-emerald-600 transition-colors">How it Works</a>
            <a href="#contact" className="hover:text-emerald-600 transition-colors">Contact</a>
            <button 
              onClick={() => openBooking()} 
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 py-2.5 rounded-full text-sm font-semibold transition-all active:scale-[0.985]"
            >
              Book Now
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="pt-20 bg-gradient-to-b from-emerald-950 to-emerald-900 text-white">
        <div className="max-w-5xl mx-auto px-6 pt-20 pb-24 text-center">
          <div className="inline-block px-4 py-1.5 bg-white/10 rounded-full text-sm mb-6 tracking-widest">MALEGAON, MAHARASHTRA</div>
          <h1 className="text-7xl font-bold tracking-tighter mb-6 leading-none">
            Professional Home Services<br />at Your Doorstep
          </h1>
          <p className="max-w-lg mx-auto text-xl text-emerald-100 mb-10">
            Trusted partner for reliable, affordable, and high-quality home maintenance. 
            Experienced professionals. Complete satisfaction guaranteed.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={() => openBooking()} 
              className="px-10 py-4 bg-white text-emerald-950 font-semibold rounded-full text-lg flex items-center justify-center gap-3 hover:bg-emerald-50 active:bg-white transition-all"
            >
              Book a Service <ArrowRight className="w-5 h-5" />
            </button>
            <button 
              onClick={() => contactWhatsApp()} 
              className="px-10 py-4 border-2 border-white/70 hover:bg-white/10 rounded-full text-lg font-semibold flex items-center justify-center gap-3 transition-all"
            >
              <Phone className="w-5 h-5" /> WhatsApp Us
            </button>
          </div>
          <div className="mt-8 text-emerald-300 text-sm flex justify-center gap-8">
            <div>₹0 Visit Charges</div>
            <div>Verified Technicians</div>
            <div>Same Day Service</div>
          </div>
        </div>
      </div>

      {/* Services Section */}
      <div id="services" className="max-w-7xl mx-auto px-6 pt-20 pb-16">
        <div className="text-center mb-12">
          <div className="text-emerald-600 text-sm tracking-[3px] font-semibold mb-2">OUR EXPERTISE</div>
          <h2 className="text-5xl font-bold tracking-tight">Our Services</h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <motion.div 
              key={service.id}
              whileHover={{ y: -4 }}
              className="group bg-white border border-gray-200 rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300"
            >
              <div className="relative h-60">
                <img 
                  src={service.image} 
                  alt={service.title} 
                  className="absolute inset-0 w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-500" 
                />
                <div className="absolute inset-0 bg-gradient-to-b from-black/30 to-black/70" />
                <div className="absolute top-5 right-5 bg-white/95 p-3 rounded-2xl text-emerald-600">
                  {service.icon}
                </div>
              </div>
              <div className="p-7">
                <h3 className="font-semibold text-2xl tracking-tight mb-2">{service.title}</h3>
                <p className="text-gray-600 mb-6">{service.description}</p>
                <div className="flex gap-3">
                  <button 
                    onClick={() => openBooking(service)} 
                    className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white py-3 rounded-full font-semibold text-sm active:bg-emerald-800 transition-all"
                  >
                    Book Now
                  </button>
                  <button 
                    onClick={() => contactWhatsApp(service.title)} 
                    className="px-6 border border-gray-300 rounded-full hover:bg-gray-50 font-medium text-sm flex items-center gap-2"
                  >
                    <Phone className="w-4 h-4" /> WhatsApp
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Why Choose Us */}
      <div id="why-us" className="bg-gray-50 py-16">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center mb-12">
            <div className="text-emerald-600 text-sm tracking-[3px] font-semibold mb-2">THE MSH DIFFERENCE</div>
            <h2 className="text-5xl font-bold tracking-tight">Why Choose MSH Service Hub?</h2>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {whyChooseUs.map((item, index) => (
              <div key={index} className="flex items-center gap-4 bg-white p-7 rounded-2xl border">
                <div className="text-emerald-600">{item.icon}</div>
                <div className="font-medium text-lg tracking-tight">{item.text}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div id="how-it-works" className="max-w-5xl mx-auto px-6 py-20">
        <div className="text-center mb-14">
          <div className="text-emerald-600 text-sm tracking-[3px] font-semibold mb-2">SIMPLE PROCESS</div>
          <h2 className="text-5xl font-bold tracking-tight">Easy Booking Process</h2>
        </div>
        
        <div className="max-w-3xl mx-auto">
          {bookingSteps.map((step, index) => (
            <div key={index} className="flex gap-6 items-start mb-8 last:mb-0">
              <div className="w-9 h-9 flex-shrink-0 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-sm">
                {index + 1}
              </div>
              <div className="pt-1">
                <div className="text-xl font-semibold tracking-tight">{step}</div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="text-center mt-10">
          <button onClick={() => openBooking()} className="px-12 py-4 bg-emerald-600 text-white font-semibold text-lg rounded-full hover:bg-emerald-700 transition-all">
            Start Booking Now
          </button>
        </div>
      </div>

      {/* Contact Section */}
      <div id="contact" className="bg-emerald-950 text-white py-20">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <div className="text-emerald-400 tracking-[3px] text-sm mb-3">GET IN TOUCH</div>
          <h2 className="text-6xl font-bold tracking-tighter mb-4">Contact Us</h2>
          <p className="text-emerald-200 text-xl mb-10">We're always available for you</p>

          <div className="flex flex-col md:flex-row justify-center gap-5 mb-14">
            <button 
              onClick={callPhone}
              className="flex items-center justify-center gap-3 bg-white text-emerald-950 px-9 py-4 rounded-full font-semibold hover:bg-emerald-100 active:bg-white text-lg"
            >
              <Phone className="w-5 h-5" /> 8855868697
            </button>
            <button 
              onClick={() => contactWhatsApp()} 
              className="flex items-center justify-center gap-3 border border-white/70 px-9 py-4 rounded-full font-semibold hover:bg-white/10 text-lg"
            >
              WhatsApp: 8855868697
            </button>
          </div>

          <div className="flex items-center justify-center gap-3 text-emerald-300">
            <MapPin className="w-5 h-5" /> Service Area: Malegaon, Maharashtra
          </div>
        </div>
      </div>

      {/* Promise Footer */}
      <div className="border-t py-9 text-center text-sm text-gray-500">
        <div className="font-medium tracking-wide mb-1">Our Promise</div>
        Quality Service • Trusted Professionals • Affordable Pricing
        <div className="mt-3 text-emerald-600">MSH Service Hub – Complete Home Solutions Under One Roof</div>
      </div>

      {/* BOOKING MODAL - Fully Functioning */}
      <AnimatePresence>
        {isBookingOpen && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur z-[60] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.96, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 20 }}
              className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden"
            >
              {!showSuccess ? (
                <>
                  {/* Modal Header */}
                  <div className="px-8 pt-8 pb-6 border-b flex justify-between items-start">
                    <div>
                      <div className="font-semibold text-3xl tracking-tight">Book Service</div>
                      <div className="text-emerald-600 text-sm mt-1">Step {currentStep} of 5</div>
                    </div>
                    <button onClick={closeBooking} className="text-3xl text-gray-400 hover:text-black">×</button>
                  </div>

                  <div className="p-8">
                    {/* STEP 1: Select Service */}
                    {currentStep === 1 && (
                      <div>
                        <div className="text-xl font-semibold mb-5">Select Your Required Service</div>
                        <div className="space-y-2.5">
                          {services.map(s => (
                            <button key={s.id} onClick={() => selectServiceInModal(s)}
                              className="w-full flex justify-between items-center border hover:border-emerald-600 px-6 py-[17px] rounded-2xl text-left transition-all active:bg-emerald-50">
                              <div className="flex items-center gap-4">
                                <div className="text-emerald-600">{s.icon}</div>
                                <div>{s.title}</div>
                              </div>
                              <ArrowRight className="text-gray-400 w-4 h-4" />
                            </button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* STEP 2: Enter Mobile */}
                    {currentStep === 2 && selectedService && (
                      <div>
                        <div className="mb-2 text-sm text-emerald-600 font-medium">SELECTED SERVICE</div>
                        <div className="font-semibold text-2xl mb-8">{selectedService.title}</div>
                        
                        <label className="block text-sm font-medium mb-2">Enter Your Mobile Number</label>
                        <div className="flex">
                          <div className="px-4 py-4 bg-gray-100 border border-r-0 rounded-l-2xl font-medium text-gray-500">+91</div>
                          <input 
                            type="tel" 
                            maxLength={10}
                            value={mobile} 
                            onChange={(e) => setMobile(e.target.value.replace(/\D/g, ''))} 
                            placeholder="8855868697" 
                            className="flex-1 border px-5 py-4 rounded-r-2xl text-xl tracking-widest focus:outline-none focus:border-emerald-600"
                          />
                        </div>
                        
                        <button 
                          onClick={sendOtp} 
                          disabled={mobile.length !== 10}
                          className="mt-6 w-full py-4 bg-emerald-600 disabled:bg-gray-300 text-white font-semibold rounded-full text-lg active:bg-emerald-700 transition-all"
                        >
                          Send OTP
                        </button>
                      </div>
                    )}

                    {/* STEP 3: Verify OTP */}
                    {currentStep === 3 && (
                      <div>
                        <div className="text-xl font-medium mb-2">Verify with OTP</div>
                        <p className="text-gray-600 mb-6">Enter the 6-digit OTP sent to +91 {mobile}</p>
                        
                        <input 
                          type="text" 
                          maxLength={6} 
                          value={otp} 
                          onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))} 
                          placeholder="000000" 
                          className="text-center w-full text-4xl tracking-[12px] py-4 border rounded-2xl focus:outline-none focus:border-emerald-600" 
                        />
                        
                        <button onClick={verifyOtp} disabled={otp.length !== 6} 
                          className="mt-6 w-full py-4 bg-emerald-600 disabled:bg-gray-300 text-white font-semibold rounded-full text-lg active:bg-emerald-700 transition-all">
                          Verify OTP
                        </button>
                      </div>
                    )}

                    {/* STEP 4: Confirm Booking */}
                    {currentStep === 4 && selectedService && (
                      <div>
                        <div className="text-xl font-medium mb-7">Confirm Your Booking</div>
                        
                        <div className="bg-gray-50 rounded-2xl p-6 space-y-4 text-sm mb-8">
                          <div className="flex justify-between"><span>Service</span> <span className="font-semibold">{selectedService.title}</span></div>
                          <div className="flex justify-between"><span>Mobile</span> <span className="font-semibold">+91 {mobile}</span></div>
                          <div className="flex justify-between"><span>Visit Charge</span> <span className="font-semibold text-emerald-600">₹0</span></div>
                        </div>

                        <button onClick={confirmBooking} className="w-full py-4 bg-emerald-600 text-white font-semibold rounded-full text-lg active:bg-emerald-700 transition-all">
                          CONFIRM BOOKING
                        </button>
                      </div>
                    )}
                  </div>
                </>
              ) : (
                /* SUCCESS SCREEN */
                <div className="p-10 text-center">
                  <div className="mx-auto w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mb-6">
                    <CheckCircle className="w-11 h-11 text-emerald-600" />
                  </div>
                  <div className="text-3xl font-semibold tracking-tight mb-3">Booking Confirmed!</div>
                  
                  {bookingDetails && (
                    <div className="text-gray-600 mb-8 leading-relaxed">
                      Your booking for <span className="font-medium text-black">{bookingDetails.service}</span> has been confirmed.<br /> 
                      We will contact you shortly on <span className="font-medium">+91 {bookingDetails.mobile}</span>.
                    </div>
                  )}

                  <div className="text-xs text-gray-500 mb-8 tracking-widest">BOOKING ID: #{bookingDetails?.bookingId}</div>

                  <div className="flex gap-3">
                    <button onClick={() => contactWhatsApp(bookingDetails?.service)} className="flex-1 py-4 border font-semibold rounded-full active:bg-gray-50">Message on WhatsApp</button>
                    <button onClick={resetAndClose} className="flex-1 py-4 bg-emerald-600 text-white font-semibold rounded-full">Done</button>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;
